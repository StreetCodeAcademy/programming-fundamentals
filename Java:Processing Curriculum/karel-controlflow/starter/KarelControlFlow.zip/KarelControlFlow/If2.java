import stanford.karel.*;

public class If2 extends SuperKarel {
	
	// Put your code into here
	public void run(){
		
	}

}
