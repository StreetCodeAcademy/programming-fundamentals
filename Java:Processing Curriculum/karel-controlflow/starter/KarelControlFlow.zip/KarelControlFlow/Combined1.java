import stanford.karel.*;

public class Combined1 extends SuperKarel {
	
	// Put your code into here
	public void run(){
		
	}

}
