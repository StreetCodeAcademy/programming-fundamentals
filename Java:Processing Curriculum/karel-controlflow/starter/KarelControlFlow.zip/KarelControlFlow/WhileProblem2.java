import stanford.karel.*;

public class WhileProblem2 extends SuperKarel {
	
	// Put your code into here
	public void run(){
		
	}

}
