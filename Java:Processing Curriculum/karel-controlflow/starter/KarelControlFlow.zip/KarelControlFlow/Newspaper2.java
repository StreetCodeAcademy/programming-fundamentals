import stanford.karel.*;

public class Newspaper2 extends SuperKarel {
	
	// Put your code into here
	public void run(){
		
	}

}
