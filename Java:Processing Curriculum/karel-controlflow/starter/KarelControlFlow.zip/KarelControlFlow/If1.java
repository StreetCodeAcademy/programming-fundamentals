import stanford.karel.*;

public class If1 extends SuperKarel {
	
	// Put your code into here
	public void run(){
		
	}

}
